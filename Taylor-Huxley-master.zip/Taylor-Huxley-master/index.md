# Von Taylor zu Huxley


### Effizienz als Dystopie - eine Untersuchung
