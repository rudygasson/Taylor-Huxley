Taylor-Huxley
=============

Von Taylor zu Huxley - Effizienz als Dystopie
